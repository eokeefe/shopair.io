(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var ToggleSwitch;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['toggle-switch'] = {
  ToggleSwitch: ToggleSwitch
};

})();
