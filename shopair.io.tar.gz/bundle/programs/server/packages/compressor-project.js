(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var getSize, responsiveSVG, GUI;

(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/compressor-project/lib/namespacing.js                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
GUI = {};                                                            // 1
///////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/compressor-project/lib/generalFCN.js                     //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/compressor-project/lib/serverFCN.js                      //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['compressor-project'] = {
  getSize: getSize,
  responsiveSVG: responsiveSVG,
  GUI: GUI
};

})();
