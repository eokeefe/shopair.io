(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var LED;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.led = {
  LED: LED
};

})();
