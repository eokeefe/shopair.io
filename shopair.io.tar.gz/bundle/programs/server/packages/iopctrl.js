(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var iopctrl;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.iopctrl = {
  iopctrl: iopctrl
};

})();
