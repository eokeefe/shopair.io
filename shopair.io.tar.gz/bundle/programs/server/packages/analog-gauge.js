(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var AnalogGauge;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['analog-gauge'] = {
  AnalogGauge: AnalogGauge
};

})();
